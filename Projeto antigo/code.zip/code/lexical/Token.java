package lexical;

import interpreter.value.Value;

public class Token {

    public static enum Type {
        // SPECIALS
        UNEXPECTED_EOF,
        INVALID_TOKEN,
        END_OF_FILE,
    
        // SYMBOLS
        // OPERATORS
        // KEYWORDS
    
        // OTHERS
        NAME,          // identifier
        NUMBER,        // integer
        TEXT           // string
    };

    public String lexeme;
    public Type type;
    public int line;
    public Value<?> literal;

    public Token(String lexeme, Type type, Value<?> literal) {
        this.lexeme = lexeme;
        this.type = type;
        this.line = 0;
        this.literal = literal;
    }

    public String toString() {
        return new StringBuffer()
            .append("(\"")
            .append(this.lexeme)
            .append("\", ")
            .append(this.type)
            .append(", ")
            .append(this.line)
            .append(", ")
            .append(this.literal)
            .append(")")
            .toString();
    }

}
