package interpreter.expr;

public class ObjectItem {
    public String key;
    public Expr value;
}