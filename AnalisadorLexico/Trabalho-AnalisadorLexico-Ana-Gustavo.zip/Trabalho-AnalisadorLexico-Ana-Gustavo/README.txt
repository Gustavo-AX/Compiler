Para executar:
1° - Com o terminal dentro da pasta compiladores, faça: 
    javac analisadorlexico/*.java interpretador/value/*.java *.java
    cd ..
    java compilador.exe
    
Os testes são feitos de forma automatica, so colocar na pasta.
